/*
 * display.h
 *
 *  Created on: Sep 9, 2024
 *      Author: compumagic
 */

#ifndef DISPLAY_H_
#define DISPLAY_H_
void display_time(void);
#endif /* DISPLAY_H_ */
