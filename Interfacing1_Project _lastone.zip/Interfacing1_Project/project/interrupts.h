#ifndef INTERRUPTS_H
#define INTERRUPTS_H

void external_interrupts_init(void);

#endif // INTERRUPTS_H
