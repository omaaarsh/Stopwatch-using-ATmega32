#ifndef TIMER_H
#define TIMER_H

void timer1_init(void);
void timer1_stop(void);
void timer1_resume(void);

#endif // TIMER_H
